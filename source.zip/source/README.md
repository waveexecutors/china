# China Client

Premium Fabric utility client for Minecraft **1.21.11**.

## Features

- **Xray** – See ores and valuable blocks through walls
- **AutoFarm** – Automatically harvest and replant crops
- **AutoSell** – Toggle and automatically run `/sell <item>` for a chosen item
- **BaseFinder** – Scan for player bases (chests, shulkers, spawners, etc.)
- **Full suite of SMP utilities**: Sprint, Fly, Speed, NoFall, Jesus, AutoTool, AutoTotem, Scaffold, Nuker, KillAura, Velocity, Criticals, ESP family, Freecam, Timer, AntiAFK, ChestStealer, AutoEat, and more
- **Modern ClickGUI** – Open with **Right Shift**
- **Accessories System** – Fullscreen menu with tabs for Bandanas, Animated Wings, Masks, Hats. Multiple can be equipped at once. Live preview + save config
- **HUD** – Large "CHINA" watermark + active modules list + coordinates/FPS

## Building with GitHub Actions

1. Push this repository to GitHub.
2. Go to **Actions** tab → select **Build China Client** → **Run workflow**.
3. Download the artifact named `China-Client` (the `.jar` file).

Alternatively, if you have Gradle locally:

```bash
./gradlew build
```

The jar will be in `build/libs/`.

## Installation

1. Install Fabric Loader for Minecraft **1.21.11**
2. Install Fabric API for 1.21.11
3. Place the China jar into your `mods` folder
4. Launch the game

## Controls

- **Right Shift** – Open / close ClickGUI
- Inside ClickGUI: Left click modules to toggle, right click category headers to collapse
- **Accessories** button (bottom right of ClickGUI) opens the fullscreen customizer

## Logo

Replace `src/main/resources/assets/china/logo.png` with your own logo (recommended 128x128 or 256x256 PNG).

## Notes

- AutoSell defaults to diamond. In-game you can change the target item via future command support or by editing the module.
- Xray requires a world reload when toggled (already handled).
- Some advanced visual features (full entity ESP, perfect Xray with Sodium, accessory 3D models) are structured and ready for extension; basic logic is present.
- This is a client-side utility mod. Use responsibly and only on servers that allow it.

## Technical

- Minecraft: **1.21.11**
- Yarn: 1.21.11+build.3
- Fabric Loader: 0.18.2+
- Fabric API: 0.141.6+1.21.11
- Loom: 1.14-SNAPSHOT
- Java: 21

## License

All Rights Reserved – China Client
