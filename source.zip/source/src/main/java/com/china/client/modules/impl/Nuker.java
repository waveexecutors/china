package com.china.client.modules.impl;

import com.china.client.modules.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

public class Nuker extends Module {
    private static final int RANGE = 3;
    private int tick = 0;

    public Nuker() {
        super("Nuker", "Breaks blocks in a radius around you", Category.WORLD);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        tick++;
        if (tick < 2) return;
        tick = 0;

        BlockPos playerPos = mc.player.getBlockPos();
        for (int x = -RANGE; x <= RANGE; x++) {
            for (int y = -RANGE; y <= RANGE; y++) {
                for (int z = -RANGE; z <= RANGE; z++) {
                    BlockPos pos = playerPos.add(x, y, z);
                    if (mc.world.getBlockState(pos).isAir()) continue;
                    if (pos.getY() < playerPos.getY() - 1) continue; // don't dig under too much
                    mc.interactionManager.attackBlock(pos, Direction.UP);
                    return; // one per tick to avoid kick
                }
            }
        }
    }
}
