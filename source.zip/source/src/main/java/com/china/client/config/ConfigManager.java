package com.china.client.config;

import com.china.client.ChinaClient;
import com.china.client.accessory.AccessoryManager;
import com.china.client.modules.Module;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import net.minecraft.client.MinecraftClient;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.HashMap;
import java.util.Map;

public class ConfigManager {
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private File configFile;

    public ConfigManager() {
        File dir = new File(MinecraftClient.getInstance().runDirectory, "china");
        if (!dir.exists()) dir.mkdirs();
        configFile = new File(dir, "config.json");
    }

    public void save() {
        try {
            JsonObject root = new JsonObject();

            // Modules
            JsonObject modules = new JsonObject();
            for (Module m : ChinaClient.INSTANCE.moduleManager.getModules()) {
                modules.addProperty(m.getName(), m.isEnabled());
            }
            root.add("modules", modules);

            // Accessories
            JsonObject accessories = new JsonObject();
            for (Map.Entry<AccessoryManager.AccessoryType, String> e : ChinaClient.INSTANCE.accessoryManager.getAllSelected().entrySet()) {
                accessories.addProperty(e.getKey().name(), e.getValue());
            }
            root.add("accessories", accessories);

            try (FileWriter writer = new FileWriter(configFile)) {
                gson.toJson(root, writer);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void load() {
        if (!configFile.exists()) return;
        try (FileReader reader = new FileReader(configFile)) {
            JsonObject root = gson.fromJson(reader, JsonObject.class);
            if (root == null) return;

            if (root.has("modules")) {
                JsonObject modules = root.getAsJsonObject("modules");
                for (Module m : ChinaClient.INSTANCE.moduleManager.getModules()) {
                    if (modules.has(m.getName())) {
                        m.setEnabled(modules.get(m.getName()).getAsBoolean());
                    }
                }
            }

            if (root.has("accessories")) {
                JsonObject accessories = root.getAsJsonObject("accessories");
                Map<String, String> data = new HashMap<>();
                accessories.entrySet().forEach(e -> data.put(e.getKey(), e.getValue().getAsString()));
                ChinaClient.INSTANCE.accessoryManager.load(data);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void saveAccessories(AccessoryManager manager) {
        save();
    }
}
