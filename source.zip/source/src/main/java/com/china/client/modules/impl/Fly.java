package com.china.client.modules.impl;

import com.china.client.modules.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Vec3d;

public class Fly extends Module {
    public Fly() {
        super("Fly", "Creative-like flight", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        mc.player.getAbilities().flying = true;
        mc.player.getAbilities().allowFlying = true;
        double speed = 0.8;
        Vec3d vel = mc.player.getVelocity();
        double y = 0;
        if (mc.options.jumpKey.isPressed()) y = speed;
        if (mc.options.sneakKey.isPressed()) y = -speed;
        mc.player.setVelocity(vel.x, y, vel.z);
    }

    @Override
    public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) {
            mc.player.getAbilities().flying = false;
            if (!mc.player.isCreative()) {
                mc.player.getAbilities().allowFlying = false;
            }
        }
    }
}
