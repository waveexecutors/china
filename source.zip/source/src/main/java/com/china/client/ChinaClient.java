package com.china.client;

import com.china.client.config.ConfigManager;
import com.china.client.gui.ClickGui;
import com.china.client.hud.HudRenderer;
import com.china.client.modules.ModuleManager;
import com.china.client.accessory.AccessoryManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

public class ChinaClient implements ClientModInitializer {
    public static final String MOD_ID = "china";
    public static ChinaClient INSTANCE;
    public static MinecraftClient mc;

    public ModuleManager moduleManager;
    public ClickGui clickGui;
    public HudRenderer hudRenderer;
    public AccessoryManager accessoryManager;
    public ConfigManager configManager;

    private boolean rightShiftPressed = false;

    @Override
    public void onInitializeClient() {
        INSTANCE = this;
        mc = MinecraftClient.getInstance();

        this.configManager = new ConfigManager();
        this.moduleManager = new ModuleManager();
        this.accessoryManager = new AccessoryManager();
        this.clickGui = new ClickGui();
        this.hudRenderer = new HudRenderer();

        this.configManager.load();
        this.moduleManager.init();
        this.accessoryManager.init();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null) return;

            // Right Shift toggle for ClickGUI
            long window = client.getWindow().getHandle();
            boolean currentlyPressed = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
            if (currentlyPressed && !rightShiftPressed) {
                clickGui.toggle();
            }
            rightShiftPressed = currentlyPressed;

            moduleManager.onTick();
            accessoryManager.onTick();
        });

        HudRenderCallback.EVENT.register((context, tickDelta) -> {
            if (mc.player != null && !mc.options.hudHidden) {
                hudRenderer.render(context, tickDelta);
            }
        });
    }
}
