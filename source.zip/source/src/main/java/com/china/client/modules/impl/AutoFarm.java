package com.china.client.modules.impl;

import com.china.client.modules.Module;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.CropBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public class AutoFarm extends Module {
    private int tickCounter = 0;
    private static final int RANGE = 4;

    public AutoFarm() {
        super("AutoFarm", "Automatically harvests and replants crops nearby", Category.WORLD);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        tickCounter++;
        if (tickCounter < 5) return;
        tickCounter = 0;

        BlockPos playerPos = mc.player.getBlockPos();
        for (int x = -RANGE; x <= RANGE; x++) {
            for (int y = -2; y <= 2; y++) {
                for (int z = -RANGE; z <= RANGE; z++) {
                    BlockPos pos = playerPos.add(x, y, z);
                    Block block = mc.world.getBlockState(pos).getBlock();

                    if (block instanceof CropBlock crop) {
                        if (crop.isMature(mc.world.getBlockState(pos))) {
                            mc.interactionManager.attackBlock(pos, Direction.UP);
                            // Attempt replant if seed available
                            tryReplant(mc, pos);
                        }
                    } else if (block == Blocks.MELON || block == Blocks.PUMPKIN) {
                        mc.interactionManager.attackBlock(pos, Direction.UP);
                    } else if (block == Blocks.SUGAR_CANE || block == Blocks.BAMBOO) {
                        BlockPos below = pos.down();
                        if (mc.world.getBlockState(below).getBlock() == block) {
                            mc.interactionManager.attackBlock(pos, Direction.UP);
                        }
                    }
                }
            }
        }
    }

    private void tryReplant(MinecraftClient mc, BlockPos pos) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (stack.isOf(Items.WHEAT_SEEDS) || stack.isOf(Items.CARROT) || stack.isOf(Items.POTATO) ||
                stack.isOf(Items.BEETROOT_SEEDS) || stack.isOf(Items.NETHER_WART)) {
                int prev = mc.player.getInventory().selectedSlot;
                mc.player.getInventory().selectedSlot = i;
                BlockHitResult hit = new BlockHitResult(Vec3d.ofCenter(pos), Direction.UP, pos, false);
                mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
                mc.player.getInventory().selectedSlot = prev;
                break;
            }
        }
    }
}
