package com.china.client.modules.impl;

import com.china.client.modules.Module;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.WorldChunk;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class BaseFinder extends Module {
    public static final List<BlockPos> foundBases = new ArrayList<>();
    private static final Set<Block> BASE_BLOCKS = new HashSet<>();
    private int scanCooldown = 0;

    static {
        BASE_BLOCKS.add(Blocks.CHEST);
        BASE_BLOCKS.add(Blocks.TRAPPED_CHEST);
        BASE_BLOCKS.add(Blocks.ENDER_CHEST);
        BASE_BLOCKS.add(Blocks.BARREL);
        BASE_BLOCKS.add(Blocks.SHULKER_BOX);
        BASE_BLOCKS.add(Blocks.WHITE_SHULKER_BOX);
        BASE_BLOCKS.add(Blocks.ORANGE_SHULKER_BOX);
        BASE_BLOCKS.add(Blocks.MAGENTA_SHULKER_BOX);
        BASE_BLOCKS.add(Blocks.LIGHT_BLUE_SHULKER_BOX);
        BASE_BLOCKS.add(Blocks.YELLOW_SHULKER_BOX);
        BASE_BLOCKS.add(Blocks.LIME_SHULKER_BOX);
        BASE_BLOCKS.add(Blocks.PINK_SHULKER_BOX);
        BASE_BLOCKS.add(Blocks.GRAY_SHULKER_BOX);
        BASE_BLOCKS.add(Blocks.LIGHT_GRAY_SHULKER_BOX);
        BASE_BLOCKS.add(Blocks.CYAN_SHULKER_BOX);
        BASE_BLOCKS.add(Blocks.PURPLE_SHULKER_BOX);
        BASE_BLOCKS.add(Blocks.BLUE_SHULKER_BOX);
        BASE_BLOCKS.add(Blocks.BROWN_SHULKER_BOX);
        BASE_BLOCKS.add(Blocks.GREEN_SHULKER_BOX);
        BASE_BLOCKS.add(Blocks.RED_SHULKER_BOX);
        BASE_BLOCKS.add(Blocks.BLACK_SHULKER_BOX);
        BASE_BLOCKS.add(Blocks.SPAWNER);
        BASE_BLOCKS.add(Blocks.BEACON);
        BASE_BLOCKS.add(Blocks.ENCHANTING_TABLE);
        BASE_BLOCKS.add(Blocks.ANVIL);
        BASE_BLOCKS.add(Blocks.HOPPER);
        BASE_BLOCKS.add(Blocks.FURNACE);
        BASE_BLOCKS.add(Blocks.BLAST_FURNACE);
        BASE_BLOCKS.add(Blocks.SMOKER);
    }

    public BaseFinder() {
        super("BaseFinder", "Scans for player bases (chests, shulkers, spawners etc.)", Category.RENDER);
    }

    @Override
    public void onEnable() {
        foundBases.clear();
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;

        scanCooldown++;
        if (scanCooldown < 20) return;
        scanCooldown = 0;

        foundBases.clear();
        ChunkPos playerChunk = mc.player.getChunkPos();
        int range = 4; // chunks

        for (int cx = -range; cx <= range; cx++) {
            for (int cz = -range; cz <= range; cz++) {
                WorldChunk chunk = mc.world.getChunk(playerChunk.x + cx, playerChunk.z + cz);
                if (chunk == null) continue;

                // Simple scan of loaded sections for base indicators
                for (int x = 0; x < 16; x++) {
                    for (int z = 0; z < 16; z++) {
                        for (int y = mc.world.getBottomY(); y < mc.world.getTopY(); y += 2) {
                            BlockPos pos = new BlockPos((playerChunk.x + cx) * 16 + x, y, (playerChunk.z + cz) * 16 + z);
                            Block block = mc.world.getBlockState(pos).getBlock();
                            if (BASE_BLOCKS.contains(block)) {
                                // Avoid duplicates nearby
                                boolean near = false;
                                for (BlockPos existing : foundBases) {
                                    if (existing.isWithinDistance(pos, 8)) {
                                        near = true;
                                        break;
                                    }
                                }
                                if (!near) {
                                    foundBases.add(pos.toImmutable());
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    public static List<BlockPos> getFoundBases() {
        return foundBases;
    }
}
