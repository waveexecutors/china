package com.china.client.modules.impl;

import com.china.client.modules.Module;

public class ChestStealer extends Module {
    public ChestStealer() {
        super("ChestStealer", "Automatically takes items from chests", Category.PLAYER);
    }
}
