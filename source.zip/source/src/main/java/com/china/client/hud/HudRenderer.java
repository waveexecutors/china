package com.china.client.hud;

import com.china.client.ChinaClient;
import com.china.client.modules.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.font.TextRenderer;

import java.util.List;

public class HudRenderer {
    public void render(DrawContext context, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        if (ChinaClient.INSTANCE.moduleManager.getModuleByName("HUD") == null ||
            !ChinaClient.INSTANCE.moduleManager.getModuleByName("HUD").isEnabled()) return;

        TextRenderer tr = mc.textRenderer;
        int screenWidth = mc.getWindow().getScaledWidth();
        int screenHeight = mc.getWindow().getScaledHeight();

        // Big watermark "CHINA"
        String watermark = "CHINA";
        int scale = 2;
        context.getMatrices().push();
        context.getMatrices().scale(scale, scale, 1);
        int wmWidth = tr.getWidth(watermark);
        context.drawTextWithShadow(tr, "§c§l" + watermark, 6, 6, 0xFF0000);
        context.getMatrices().pop();

        // Subtitle
        context.drawTextWithShadow(tr, "§7v1.0.0 | Premium", 8, 28, 0xAAAAAA);

        // Active modules list (right side)
        List<Module> enabled = ChinaClient.INSTANCE.moduleManager.getEnabledModules();
        int y = 8;
        for (Module mod : enabled) {
            if (mod.getName().equals("HUD") || mod.getName().equals("ClickGUI")) continue;
            String text = mod.getName();
            int textWidth = tr.getWidth(text);
            // Background bar
            context.fill(screenWidth - textWidth - 14, y - 1, screenWidth - 4, y + 11, 0x88000000);
            // Accent
            context.fill(screenWidth - 4, y - 1, screenWidth - 2, y + 11, 0xFFCC0000);
            context.drawTextWithShadow(tr, "§f" + text, screenWidth - textWidth - 10, y, 0xFFFFFF);
            y += 13;
        }

        // Info bottom left
        if (mc.player != null) {
            String coords = String.format("§7XYZ §f%.0f §7%.0f §7%.0f", mc.player.getX(), mc.player.getY(), mc.player.getZ());
            context.drawTextWithShadow(tr, coords, 8, screenHeight - 30, 0xFFFFFF);
            String fps = "§7FPS §f" + mc.getCurrentFps();
            context.drawTextWithShadow(tr, fps, 8, screenHeight - 18, 0xFFFFFF);
        }
    }
}
