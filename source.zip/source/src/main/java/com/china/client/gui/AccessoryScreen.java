package com.china.client.gui;

import com.china.client.ChinaClient;
import com.china.client.accessory.AccessoryManager;
import com.china.client.accessory.AccessoryManager.AccessoryType;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.text.Text;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.lwjgl.glfw.GLFW;

public class AccessoryScreen extends Screen {
    private AccessoryType currentTab = AccessoryType.BANDANA;
    private int selectedIndex = 0;
    private float playerYaw = 180f;

    public AccessoryScreen() {
        super(Text.literal("China Accessories"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Full dark background
        context.fill(0, 0, width, height, 0xEE0A0A0A);

        // Header
        context.fill(0, 0, width, 36, 0xFF111111);
        context.drawCenteredTextWithShadow(textRenderer, "§c§lCHINA §fAccessories Customizer", width / 2, 12, 0xFFFFFF);

        // Tabs
        int tabWidth = 100;
        int tabStartX = 40;
        AccessoryType[] tabs = AccessoryType.values();
        for (int i = 0; i < tabs.length; i++) {
            int tx = tabStartX + i * (tabWidth + 8);
            boolean selected = tabs[i] == currentTab;
            boolean hover = mouseX >= tx && mouseX <= tx + tabWidth && mouseY >= 50 && mouseY <= 74;
            int color = selected ? 0xFFCC0000 : (hover ? 0xFF444444 : 0xFF222222);
            context.fill(tx, 50, tx + tabWidth, 74, color);
            context.drawCenteredTextWithShadow(textRenderer, "§f" + tabs[i].name(), tx + tabWidth / 2, 58, 0xFFFFFF);
        }

        // Left side - variant list
        context.fill(30, 100, 280, height - 80, 0xFF151515);
        context.drawTextWithShadow(textRenderer, "§7Select Variant:", 40, 110, 0xFFFFFF);

        String[] variants = AccessoryManager.getVariants(currentTab);
        int listY = 130;
        for (int i = 0; i < variants.length; i++) {
            boolean selected = i == selectedIndex;
            boolean hover = mouseX >= 40 && mouseX <= 260 && mouseY >= listY && mouseY <= listY + 18;
            int bg = selected ? 0xFFAA0000 : (hover ? 0xFF333333 : 0x00000000);
            context.fill(40, listY, 260, listY + 18, bg);
            String name = variants[i].equals("none") ? "§8None" : "§f" + capitalize(variants[i]);
            context.drawTextWithShadow(textRenderer, name, 48, listY + 5, 0xFFFFFF);
            listY += 20;
        }

        // Preview area
        context.fill(width - 320, 100, width - 40, height - 80, 0xFF151515);
        context.drawCenteredTextWithShadow(textRenderer, "§7Preview", width - 180, 110, 0xAAAAAA);

        // Draw player model preview (simplified text representation + note)
        // In full client this would use InventoryScreen.drawEntity or EntityRenderDispatcher
        if (client != null && client.player != null) {
            try {
                drawEntity(context, width - 180, height / 2 + 40, 60, playerYaw, -10, client.player);
            } catch (Exception e) {
                context.drawCenteredTextWithShadow(textRenderer, "§7[Player Preview]", width - 180, height / 2, 0xFFFFFF);
            }
        }

        // Current selection info
        String current = ChinaClient.INSTANCE.accessoryManager.getSelected(currentTab);
        context.drawCenteredTextWithShadow(textRenderer, "§7Equipped: §f" + capitalize(current), width - 180, height - 100, 0xFFFFFF);

        // Save button
        int saveX = width / 2 - 60;
        int saveY = height - 50;
        boolean saveHover = mouseX >= saveX && mouseX <= saveX + 120 && mouseY >= saveY && mouseY <= saveY + 28;
        context.fill(saveX, saveY, saveX + 120, saveY + 28, saveHover ? 0xFF00AA00 : 0xFF006600);
        context.drawCenteredTextWithShadow(textRenderer, "§fSave Config", saveX + 60, saveY + 10, 0xFFFFFF);

        // Back
        context.drawTextWithShadow(textRenderer, "§7[ESC] Back", 20, height - 30, 0xAAAAAA);

        // Rotate hint
        context.drawCenteredTextWithShadow(textRenderer, "§8Drag to rotate preview", width - 180, height - 70, 0x666666);

        super.render(context, mouseX, mouseY, delta);
    }

    private void drawEntity(DrawContext context, int x, int y, int size, float yaw, float pitch, LivingEntity entity) {
        // Simplified: real implementation uses matrices and EntityRenderDispatcher
        // Placeholder visual
        context.fill(x - 40, y - 80, x + 40, y + 20, 0x33FFFFFF);
        context.drawCenteredTextWithShadow(textRenderer, "§fYOU", x, y - 30, 0xFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer, "§7(Preview Model)", x, y - 15, 0xAAAAAA);
        // Note: Full rendering requires Mixin or InventoryScreen.drawEntity call which is private;
        // in production use reflection or copied method from InventoryScreen.
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        // Tabs
        int tabWidth = 100;
        int tabStartX = 40;
        AccessoryType[] tabs = AccessoryType.values();
        for (int i = 0; i < tabs.length; i++) {
            int tx = tabStartX + i * (tabWidth + 8);
            if (mouseX >= tx && mouseX <= tx + tabWidth && mouseY >= 50 && mouseY <= 74) {
                currentTab = tabs[i];
                selectedIndex = 0;
                String current = ChinaClient.INSTANCE.accessoryManager.getSelected(currentTab);
                String[] vars = AccessoryManager.getVariants(currentTab);
                for (int j = 0; j < vars.length; j++) {
                    if (vars[j].equals(current)) {
                        selectedIndex = j;
                        break;
                    }
                }
                return true;
            }
        }

        // Variant list
        String[] variants = AccessoryManager.getVariants(currentTab);
        int listY = 130;
        for (int i = 0; i < variants.length; i++) {
            if (mouseX >= 40 && mouseX <= 260 && mouseY >= listY && mouseY <= listY + 18) {
                selectedIndex = i;
                ChinaClient.INSTANCE.accessoryManager.setSelected(currentTab, variants[i]);
                return true;
            }
            listY += 20;
        }

        // Save
        int saveX = width / 2 - 60;
        int saveY = height - 50;
        if (mouseX >= saveX && mouseX <= saveX + 120 && mouseY >= saveY && mouseY <= saveY + 28) {
            ChinaClient.INSTANCE.accessoryManager.save();
            if (client != null && client.player != null) {
                client.player.sendMessage(Text.literal("§a[China] Accessories config saved!"), false);
            }
            return true;
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (mouseX > width - 320) {
            playerYaw += (float) deltaX * 0.5f;
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            if (client != null) {
                client.setScreen(ChinaClient.INSTANCE.clickGui);
            }
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private String capitalize(String s) {
        if (s == null || s.isEmpty()) return s;
        return s.substring(0, 1).toUpperCase() + s.substring(1);
    }
}
