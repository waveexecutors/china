package com.china.client.modules.impl;

import com.china.client.modules.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;

public class AutoEat extends Module {
    public AutoEat() {
        super("AutoEat", "Automatically eats food when hungry", Category.PLAYER);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.player.getHungerManager().getFoodLevel() > 14) return;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (stack.getItem().getComponents().contains(net.minecraft.component.DataComponentTypes.FOOD)) {
                int prev = mc.player.getInventory().selectedSlot;
                mc.player.getInventory().selectedSlot = i;
                mc.options.useKey.setPressed(true);
                // simplistic
                return;
            }
        }
    }
}
