package com.china.client.modules.impl;

import com.china.client.modules.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Vec3d;

public class AntiAFK extends Module {
    private int tick = 0;

    public AntiAFK() {
        super("AntiAFK", "Prevents AFK kick by small movements", Category.MISC);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        tick++;
        if (tick > 100) {
            tick = 0;
            mc.player.setYaw(mc.player.getYaw() + 1);
        }
    }
}
