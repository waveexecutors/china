package com.china.client.accessory;

import net.minecraft.client.MinecraftClient;
import java.util.HashMap;
import java.util.Map;

public class AccessoryManager {
    public enum AccessoryType {
        BANDANA, WINGS, MASK, HAT
    }

    private final Map<AccessoryType, String> selected = new HashMap<>();
    private final Map<AccessoryType, Boolean> enabled = new HashMap<>();

    public void init() {
        for (AccessoryType type : AccessoryType.values()) {
            selected.put(type, "none");
            enabled.put(type, false);
        }
        // Defaults for demo
        selected.put(AccessoryType.BANDANA, "red");
        selected.put(AccessoryType.WINGS, "dragon");
        selected.put(AccessoryType.MASK, "oni");
        selected.put(AccessoryType.HAT, "crown");
    }

    public void onTick() {
        // Rendering handled via mixins / entity renderer hooks in full implementation
    }

    public void setSelected(AccessoryType type, String variant) {
        selected.put(type, variant);
        enabled.put(type, !"none".equals(variant));
    }

    public String getSelected(AccessoryType type) {
        return selected.getOrDefault(type, "none");
    }

    public boolean isEnabled(AccessoryType type) {
        return enabled.getOrDefault(type, false);
    }

    public void toggle(AccessoryType type) {
        boolean current = enabled.getOrDefault(type, false);
        enabled.put(type, !current);
        if (!enabled.get(type)) {
            selected.put(type, "none");
        }
    }

    public Map<AccessoryType, String> getAllSelected() {
        return new HashMap<>(selected);
    }

    public void save() {
        // Persist via ConfigManager
        if (com.china.client.ChinaClient.INSTANCE.configManager != null) {
            com.china.client.ChinaClient.INSTANCE.configManager.saveAccessories(this);
        }
    }

    public void load(Map<String, String> data) {
        for (Map.Entry<String, String> e : data.entrySet()) {
            try {
                AccessoryType type = AccessoryType.valueOf(e.getKey());
                setSelected(type, e.getValue());
            } catch (Exception ignored) {}
        }
    }

    // Variants available
    public static String[] getVariants(AccessoryType type) {
        return switch (type) {
            case BANDANA -> new String[]{"none", "red", "blue", "black", "camo", "gold", "white", "purple"};
            case WINGS -> new String[]{"none", "dragon", "angel", "demon", "butterfly", "bat", "phoenix", "crystal"};
            case MASK -> new String[]{"none", "oni", "fox", "skull", "gas", "ninja", "plague", "cyber"};
            case HAT -> new String[]{"none", "crown", "fedora", "cap", "wizard", "viking", "beanie", "top"};
        };
    }

