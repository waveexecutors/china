package com.china.client.modules.impl;

import com.china.client.modules.Module;

public class NoRender extends Module {
    public NoRender() {
        super("NoRender", "Disables certain rendering (fire, particles etc.)", Category.RENDER);
    }
}
