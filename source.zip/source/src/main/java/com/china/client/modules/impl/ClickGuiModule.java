package com.china.client.modules.impl;

import com.china.client.modules.Module;

public class ClickGuiModule extends Module {
    public ClickGuiModule() {
        super("ClickGUI", "Opens the ClickGUI (Right Shift)", Category.CLIENT);
    }
}
