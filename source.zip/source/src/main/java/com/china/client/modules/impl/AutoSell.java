package com.china.client.modules.impl;

import com.china.client.modules.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

public class AutoSell extends Module {
    private Item selectedItem = null;
    private int tickDelay = 0;
    private static final int SELL_INTERVAL = 40; // every 2 seconds

    public AutoSell() {
        super("AutoSell", "Automatically sells selected item via /sell command. Toggle then choose item.", Category.PLAYER);
    }

    @Override
    public void onEnable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        // Open a simple selection by sending message or using a screen later
        // For now, default to diamonds, user can change via command or future GUI
        if (selectedItem == null) {
            selectedItem = Items.DIAMOND;
            if (mc.player != null) {
                mc.player.sendMessage(net.minecraft.text.Text.literal("§a[China] AutoSell enabled. Default: Diamond. Use /china sell <item> to change."), false);
            }
        }
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || selectedItem == null) return;

        tickDelay++;
        if (tickDelay < SELL_INTERVAL) return;
        tickDelay = 0;

        // Check if player has the item
        int count = 0;
        for (int i = 0; i < mc.player.getInventory().size(); i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (stack.isOf(selectedItem)) {
                count += stack.getCount();
            }
        }

        if (count > 0) {
            String itemId = Registries.ITEM.getId(selectedItem).getPath();
            mc.player.networkHandler.sendChatCommand("sell " + itemId);
        }
    }

    public void setSelectedItem(Item item) {
        this.selectedItem = item;
    }

    public Item getSelectedItem() {
        return selectedItem;
    }

    public void setSelectedItemByName(String name) {
        try {
            Item item = Registries.ITEM.get(Identifier.of("minecraft", name.toLowerCase()));
            if (item != Items.AIR) {
                this.selectedItem = item;
            }
        } catch (Exception ignored) {}
    }
}
