package com.china.client.modules.impl;

import com.china.client.modules.Module;

public class StorageESP extends Module {
    public StorageESP() {
        super("StorageESP", "Highlights storage blocks", Category.RENDER);
    }
}
