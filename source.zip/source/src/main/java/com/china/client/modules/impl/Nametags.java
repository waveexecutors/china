package com.china.client.modules.impl;

import com.china.client.modules.Module;

public class Nametags extends Module {
    public Nametags() {
        super("Nametags", "Enhanced player nametags", Category.RENDER);
    }
}
