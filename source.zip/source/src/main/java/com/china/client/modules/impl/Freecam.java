package com.china.client.modules.impl;

import com.china.client.modules.Module;

public class Freecam extends Module {
    public Freecam() {
        super("Freecam", "Detach camera from player", Category.RENDER);
    }
}
