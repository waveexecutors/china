package com.china.client.modules.impl;

import com.china.client.modules.Module;

public class ViewClip extends Module {
    public ViewClip() {
        super("ViewClip", "Allows camera to clip through blocks in F5", Category.RENDER);
    }
}
