package com.china.client.modules.impl;

import com.china.client.modules.Module;

public class PlayerESP extends Module {
    public PlayerESP() {
        super("PlayerESP", "Highlights other players", Category.RENDER);
    }
}
