package com.china.client.gui;

import com.china.client.ChinaClient;
import com.china.client.modules.Module;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.List;

public class Panel {
    public final Module.Category category;
    public int x, y;
    private boolean expanded = true;
    private static final int WIDTH = 110;
    private static final int HEADER_HEIGHT = 18;
    private static final int MODULE_HEIGHT = 16;

    public Panel(Module.Category category, int x, int y) {
        this.category = category;
        this.x = x;
        this.y = y;
    }

    public void render(DrawContext context, int mouseX, int mouseY, TextRenderer textRenderer) {
        List<Module> modules = ChinaClient.INSTANCE.moduleManager.getModulesByCategory(category);

        // Header
        boolean headerHover = isHeaderHovered(mouseX, mouseY);
        context.fill(x, y, x + WIDTH, y + HEADER_HEIGHT, headerHover ? 0xFFCC1111 : 0xFF990000);
        context.drawCenteredTextWithShadow(textRenderer, "§f" + category.getName(), x + WIDTH / 2, y + 5, 0xFFFFFF);

        if (!expanded) return;

        int currentY = y + HEADER_HEIGHT;
        for (Module mod : modules) {
            boolean modHover = mouseX >= x && mouseX <= x + WIDTH && mouseY >= currentY && mouseY <= currentY + MODULE_HEIGHT;
            int bg = mod.isEnabled() ? 0xFF22AA22 : (modHover ? 0xFF333333 : 0xFF1A1A1A);
            context.fill(x, currentY, x + WIDTH, currentY + MODULE_HEIGHT, bg);
            context.drawTextWithShadow(textRenderer, (mod.isEnabled() ? "§a" : "§7") + mod.getName(), x + 4, currentY + 4, 0xFFFFFF);
            currentY += MODULE_HEIGHT;
        }

        // Border
        context.fill(x, y + HEADER_HEIGHT, x + 1, currentY, 0xFFCC0000);
        context.fill(x + WIDTH - 1, y + HEADER_HEIGHT, x + WIDTH, currentY, 0xFFCC0000);
        context.fill(x, currentY - 1, x + WIDTH, currentY, 0xFFCC0000);
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (isHeaderHovered(mouseX, mouseY)) {
            if (button == 1) { // right click toggle expand
                expanded = !expanded;
            }
            return true;
        }

        if (!expanded) return false;

        List<Module> modules = ChinaClient.INSTANCE.moduleManager.getModulesByCategory(category);
        int currentY = y + HEADER_HEIGHT;
        for (Module mod : modules) {
            if (mouseX >= x && mouseX <= x + WIDTH && mouseY >= currentY && mouseY <= currentY + MODULE_HEIGHT) {
                if (button == 0) {
                    mod.toggle();
                }
                return true;
            }
            currentY += MODULE_HEIGHT;
        }
        return false;
    }

    public boolean isHeaderHovered(double mouseX, double mouseY) {
        return mouseX >= x && mouseX <= x + WIDTH && mouseY >= y && mouseY <= y + HEADER_HEIGHT;
    }
}
