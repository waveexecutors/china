package com.china.client.modules.impl;

import com.china.client.modules.Module;

public class Tracers extends Module {
    public Tracers() {
        super("Tracers", "Draws lines to entities", Category.RENDER);
    }
}
