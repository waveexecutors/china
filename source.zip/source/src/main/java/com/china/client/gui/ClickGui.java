package com.china.client.gui;

import com.china.client.ChinaClient;
import com.china.client.modules.Module;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class ClickGui extends Screen {
    private boolean open = false;
    private final List<Panel> panels = new ArrayList<>();
    private int dragX, dragY;
    private Panel draggingPanel = null;

    public ClickGui() {
        super(Text.literal("China ClickGUI"));
        int x = 20;
        for (Module.Category cat : Module.Category.values()) {
            panels.add(new Panel(cat, x, 30));
            x += 120;
        }
    }

    public void toggle() {
        open = !open;
        if (open) {
            MinecraftClientAccessor.openScreen(this);
        } else {
            MinecraftClientAccessor.closeScreen();
        }
    }

    public boolean isOpen() {
        return open;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Semi transparent dark background
        context.fill(0, 0, width, height, 0xAA000000);

        // Title bar
        context.fill(0, 0, width, 24, 0xFF0A0A0A);
        context.drawCenteredTextWithShadow(textRenderer, "§c§lCHINA §7| Premium Utility Client", width / 2, 8, 0xFFFFFF);

        for (Panel panel : panels) {
            panel.render(context, mouseX, mouseY, textRenderer);
        }

        // Accessories button
        int btnX = width - 140;
        int btnY = height - 40;
        boolean hovered = mouseX >= btnX && mouseX <= btnX + 120 && mouseY >= btnY && mouseY <= btnY + 28;
        context.fill(btnX, btnY, btnX + 120, btnY + 28, hovered ? 0xFFCC0000 : 0xFF880000);
        context.drawCenteredTextWithShadow(textRenderer, "§fAccessories", btnX + 60, btnY + 10, 0xFFFFFF);

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        // Accessories button
        int btnX = width - 140;
        int btnY = height - 40;
        if (mouseX >= btnX && mouseX <= btnX + 120 && mouseY >= btnY && mouseY <= btnY + 28) {
            if (client != null) {
                client.setScreen(new AccessoryScreen());
            }
            return true;
        }

        for (Panel panel : panels) {
            if (panel.mouseClicked(mouseX, mouseY, button)) {
                if (button == 0 && panel.isHeaderHovered(mouseX, mouseY)) {
                    draggingPanel = panel;
                    dragX = (int) mouseX - panel.x;
                    dragY = (int) mouseY - panel.y;
                }
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        draggingPanel = null;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (draggingPanel != null) {
            draggingPanel.x = (int) mouseX - dragX;
            draggingPanel.y = (int) mouseY - dragY;
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            toggle();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    // Helper to avoid direct MinecraftClient dependency issues in some contexts
    private static class MinecraftClientAccessor {
        static void openScreen(Screen screen) {
            net.minecraft.client.MinecraftClient.getInstance().setScreen(screen);
        }
        static void closeScreen() {
            net.minecraft.client.MinecraftClient.getInstance().setScreen(null);
        }
    }
}
