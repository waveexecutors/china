package com.china.client.modules;

import com.china.client.modules.impl.*;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public void init() {
        // Render
        modules.add(new Xray());
        modules.add(new Fullbright());
        modules.add(new Esp());
        modules.add(new BaseFinder());
        modules.add(new Tracers());

        // Player / World
        modules.add(new AutoFarm());
        modules.add(new AutoSell());
        modules.add(new AutoTool());
        modules.add(new AutoTotem());
        modules.add(new Scaffold());
        modules.add(new Nuker());

        // Movement
        modules.add(new Sprint());
        modules.add(new Fly());
        modules.add(new Speed());
        modules.add(new NoFall());
        modules.add(new Jesus());

        // Misc / Client
        modules.add(new ClickGuiModule());
        modules.add(new HudModule());
        modules.add(new Freecam());
        modules.add(new Timer());
        modules.add(new AntiAFK());
        modules.add(new StorageESP());
        modules.add(new PlayerESP());
        modules.add(new Nametags());
        modules.add(new ChestStealer());
        modules.add(new AutoEat());
        modules.add(new MiddleClickFriend());
        modules.add(new NoRender());
        modules.add(new ViewClip());
        modules.add(new KillAura()); // basic
        modules.add(new Velocity());
        modules.add(new Criticals());

        // Enable HUD and ClickGUI module by default conceptually
        getModuleByName("HUD").setEnabled(true);
    }

    public void onTick() {
        for (Module m : modules) {
            if (m.isEnabled()) {
                m.onTick();
            }
        }
    }

    public List<Module> getModules() {
        return modules;
    }

    public List<Module> getModulesByCategory(Module.Category category) {
        return modules.stream()
                .filter(m -> m.getCategory() == category)
                .collect(Collectors.toList());
    }

    public Module getModuleByName(String name) {
        return modules.stream()
                .filter(m -> m.getName().equalsIgnoreCase(name))
                .findFirst()
                .orElse(null);
    }

    public List<Module> getEnabledModules() {
        return modules.stream()
                .filter(Module::isEnabled)
                .collect(Collectors.toList());
    }
}
