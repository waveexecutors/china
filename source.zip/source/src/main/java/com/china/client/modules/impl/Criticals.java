package com.china.client.modules.impl;

import com.china.client.modules.Module;

public class Criticals extends Module {
    public Criticals() {
        super("Criticals", "Forces critical hits", Category.COMBAT);
    }
}
