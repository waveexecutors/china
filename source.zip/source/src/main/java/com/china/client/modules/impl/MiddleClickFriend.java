package com.china.client.modules.impl;

import com.china.client.modules.Module;

public class MiddleClickFriend extends Module {
    public MiddleClickFriend() {
        super("MiddleClickFriend", "Middle click to add friends", Category.MISC);
    }
}
