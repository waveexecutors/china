package com.china.client.modules.impl;

import com.china.client.modules.Module;

public class Timer extends Module {
    public Timer() {
        super("Timer", "Changes game tick rate", Category.MISC);
    }
}
