package com.china.client.modules.impl;

import com.china.client.modules.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Vec3d;

public class Speed extends Module {
    public Speed() {
        super("Speed", "Increases movement speed", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || !mc.player.isOnGround()) return;
        if (mc.player.forwardSpeed > 0 || mc.player.sidewaysSpeed != 0) {
            double mult = 1.6;
            Vec3d vel = mc.player.getVelocity();
            mc.player.setVelocity(vel.x * mult, vel.y, vel.z * mult);
        }
    }
}
