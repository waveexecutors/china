package com.china.client.modules.impl;

import com.china.client.modules.Module;

public class Velocity extends Module {
    public Velocity() {
        super("Velocity", "Reduces knockback", Category.COMBAT);
    }
}
