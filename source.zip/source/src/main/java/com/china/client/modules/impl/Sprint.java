package com.china.client.modules.impl;

import com.china.client.modules.Module;
import net.minecraft.client.MinecraftClient;

public class Sprint extends Module {
    public Sprint() {
        super("Sprint", "Automatically sprints", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && mc.player.forwardSpeed > 0 && !mc.player.isSprinting() && !mc.player.isUsingItem()) {
            mc.player.setSprinting(true);
        }
    }
}
