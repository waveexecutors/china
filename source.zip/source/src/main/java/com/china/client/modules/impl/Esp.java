package com.china.client.modules.impl;

import com.china.client.modules.Module;

public class Esp extends Module {
    public Esp() {
        super("ESP", "Highlights entities through walls", Category.RENDER);
    }
}
