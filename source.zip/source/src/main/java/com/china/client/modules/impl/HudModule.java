package com.china.client.modules.impl;

import com.china.client.modules.Module;

public class HudModule extends Module {
    public HudModule() {
        super("HUD", "Displays the China watermark and module list", Category.CLIENT);
    }
}
